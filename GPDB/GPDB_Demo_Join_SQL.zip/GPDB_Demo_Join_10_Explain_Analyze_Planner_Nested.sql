\echo ##########################
\echo ##### Test6
\echo ##########################
explain analyze select * from test_join_smallint A
inner join test_join_bigint B
on A.field1_smallint = B.field1_bigint;



\echo ##########################
\echo ##### Test8
\echo ##########################
explain analyze select * from test_join_date_analyzed A
inner join test_join_timestamp_analyzed B
on A.field1_date = B.field1_timestamp;
