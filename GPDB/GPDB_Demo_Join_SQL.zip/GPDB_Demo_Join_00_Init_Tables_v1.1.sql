Set gp_autostats_mode=NONE;

drop table if exists test_data_init;
create table test_data_init (seq bigint, attr_text text) distributed by (seq);
insert into test_data_init 
select seq::bigint as field1_bigint,'attr value' || mod(seq,1250)::text as attr_text
from (select generate_series(1,10000000) as seq) T;

-- Text-Varchar Distributed Tables
drop table if exists  test_join_vc30;
create table test_join_vc30 (field1_vc30 varchar(30) ,attr_text text)
distributed by (field1_vc30);
insert into test_join_vc30 
select seq, attr_text from test_data_init T;


drop table if exists  test_join_vc60;
create table test_join_vc60 (field1_vc60 varchar(60) ,attr_text text)
distributed by (field1_vc60);
insert into test_join_vc60 
select seq, attr_text from test_data_init T;


drop table if exists  test_join_vc;
create table test_join_vc (field1_vc varchar, attr_text text)
distributed by (field1_vc);
insert into test_join_vc
select seq, attr_text from test_data_init T;


drop table if exists  test_join_text;
create table test_join_text (field1_text text, attr_text text)
distributed by (field1_text);
insert into test_join_text select seq , attr_text from test_data_init T;


-- Numeric Distributed Tables
drop table if exists  test_join_bigint;
create table test_join_bigint (field1_bigint bigint, attr_text text)
distributed by (field1_bigint);
insert into test_join_bigint
select seq, attr_text from test_data_init T;

drop table if exists  test_join_bigint_analyzed;
create table test_join_bigint_analyzed (like test_join_bigint);
insert into test_join_bigint_analyzed select * from test_join_bigint;
Analyze test_join_bigint_analyzed;

drop table if exists  test_join_numeric;
create table test_join_numeric (field1_numeric numeric, attr_text text)
distributed by (field1_numeric);
insert into test_join_numeric
select seq, attr_text from test_data_init T;

drop table if exists  test_join_numeric_analyzed;
create table test_join_numeric_analyzed (like test_join_numeric);
insert into test_join_numeric_analyzed select * from test_join_numeric;
Analyze test_join_numeric_analyzed;

drop table if exists  test_join_bigint_bis;
create table test_join_bigint_bis (field1_bigint bigint, attr_text text)
distributed by (field1_bigint);
insert into test_join_bigint_bis 
select seq, attr_text from test_data_init T;

drop table if exists  test_join_bigint_small;
create table test_join_bigint_small (field1_bigint bigint, attr_text text)
distributed by (field1_bigint);
insert into test_join_bigint_small
select seq::bigint as field1_bigint,'attr value' || mod(seq,1250)::text as attr_text
from (select generate_series(1,1000,4) as seq) T;

drop table if exists  test_join_bigint_small_analyzed;
create table test_join_bigint_small_analyzed (like test_join_bigint_small);
insert into test_join_bigint_small_analyzed select * from test_join_bigint_small;
Analyze test_join_bigint_small_analyzed;

drop table if exists  test_join_smallint;
create table test_join_smallint (field1_smallint smallint, attr_text text)
distributed by (field1_smallint);
insert into test_join_smallint
select seq, attr_text from test_data_init T
where seq <= 32000;

-- Randomly Distributed Tables
drop table if exists test_join_random_big;
create table test_join_random_big (field1_bigint bigint, attr_text text)
distributed randomly;
insert into test_join_random_big
select seq, attr_text from test_data_init T;

drop table if exists  test_join_random_small;
create table test_join_random_small (field1_bigint bigint, attr_text text)
distributed randomly;
insert into test_join_random_small
select seq, attr_text from test_data_init T;


Drop table if exists test_join_random_big_analyzed;
Create table test_join_random_big_analyzed (like test_join_random_big );
Insert into test_join_random_big_analyzed select * from test_join_random_big;
Analyze test_join_random_big_analyzed;

Drop table if exists test_join_random_small_analyzed;
Create table test_join_random_small_analyzed (like test_join_random_small);
Insert into test_join_random_small_analyzed select * from test_join_random_small;
Analyze test_join_random_small_analyzed;


-- Timestamp-Date Distributed Tables
drop table if exists  test_join_timestamp_analyzed;
create table test_join_timestamp_analyzed (field1_timestamp timestamp, attr_text text)
distributed by (field1_timestamp);
insert into test_join_timestamp_analyzed 
select '0001-01-01'::date + seq::bigint * interval '1 day', attr_text
from test_data_init T
where seq < 1000000;
analyze test_join_timestamp_analyzed;

drop table if exists  test_join_date_analyzed;
create table test_join_date_analyzed (field1_date date, attr_text text)
distributed by (field1_date);
insert into test_join_date_analyzed
select '0001-01-01'::date + seq::bigint * interval '1 day', attr_text
from test_data_init T
where seq < 1000000;
analyze test_join_date_analyzed;


-- Multi-fields DK
Set gp_autostats_mode=ON_NO_STATS;
drop table if exists test_DK_1_2;
drop table if exists test_DK_2_1;
drop table if exists test_DK_1_2_bis;

create table test_DK_1_2
(field1_bigint bigint, field2_bigint bigint, field3_text text)
distributed by (field1_bigint, field2_bigint);
create table test_DK_2_1
(field1_bigint bigint, field2_bigint bigint, field3_text text)
distributed by (field2_bigint, field1_bigint);
create table test_DK_1_2_bis
(field1_bigint bigint, field2_bigint bigint, field3_text text)
distributed by (field1_bigint, field2_bigint);

insert into test_DK_1_2 select mod(seq,1000), seq, 'test' from test_data_init T;
insert into test_DK_2_1 select mod(seq,1000), seq, 'test' from test_data_init T;
insert into test_DK_1_2_bis select mod(seq,1000), seq, 'test' from test_data_init T;