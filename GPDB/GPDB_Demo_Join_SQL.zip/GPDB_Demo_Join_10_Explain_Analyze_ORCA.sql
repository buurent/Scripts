set optimizer=on;
\echo ##########################
\echo ##### Test1
\echo ##########################
explain analyze select * from test_join_vc30 A
inner join test_join_vc60 B
on A.field1_vc30 = B.field1_vc60;

\echo ##########################
\echo ##### Test2
\echo ##########################
explain analyze select * from test_join_vc30 A
inner join test_join_vc B
on A.field1_vc30 = B.field1_vc;

\echo ##########################
\echo ##### Test3
\echo ##########################
explain analyze select * from test_join_vc30 A
inner join test_join_text B
on A.field1_vc30 = B.field1_text;

\echo ##########################
\echo ##### Test4
\echo ##########################
explain analyze select * from test_join_vc30 A
inner join test_join_bigint B
on A.field1_vc30 = B.field1_bigint;

\echo ##########################
\echo ##### Test5
\echo ##########################
explain analyze select * from test_join_numeric A
inner join test_join_bigint B
on A.field1_numeric = B.field1_bigint;

\echo ##########################
\echo ##### Test6
\echo ##########################
explain analyze select * from test_join_smallint A
inner join test_join_bigint B
on A.field1_smallint = B.field1_bigint;

\echo ##########################
\echo ##### Test6b
\echo ##########################
explain analyze select * from test_join_smallint A
inner join test_join_bigint B
on A.field1_smallint::bigint = B.field1_bigint;

\echo ##########################
\echo ##### Test7
\echo ##########################
explain analyze select * from test_join_bigint_bis A
inner join test_join_bigint B
on A.field1_bigint = B.field1_bigint;

\echo ##########################
\echo ##### Test8
\echo ##########################
explain analyze select * from test_join_date_analyzed A
inner join test_join_timestamp_analyzed B
on A.field1_date = B.field1_timestamp;

\echo ##########################
\echo ##### Test8b
\echo ##########################
explain analyze select * from test_join_date_analyzed A
inner join test_join_timestamp_analyzed B
on A.field1_date = B.field1_timestamp::date;

\echo ##########################
\echo ##### Test9
\echo ##########################
explain analyze select * from test_join_random_big A
inner join test_join_bigint B
on A.field1_bigint = B.field1_bigint;

\echo ##########################
\echo ##### Test10
\echo ##########################
explain analyze select * from test_join_random_big A
inner join test_join_bigint_small B
on A.field1_bigint = B.field1_bigint;

\echo ##########################
\echo ##### Test10b
\echo ##########################
explain analyze select * from test_join_random_big_analyzed A
inner join test_join_bigint_small_analyzed B
on A.field1_bigint = B.field1_bigint;

\echo ##########################
\echo ##### Test11
\echo ##########################
explain analyze select * from test_join_random_small A
inner join test_join_numeric B
on A.field1_bigint = B.field1_numeric;

\echo ##########################
\echo ##### Test11b
\echo ##########################
explain analyze select * from test_join_random_small_analyzed A
inner join test_join_numeric_analyzed B
on A.field1_bigint = B.field1_numeric;

\echo ##########################
\echo ##### Test12
\echo ##########################
explain analyze select * from test_join_random_small A
inner join test_join_random_big B
on A.field1_bigint = B.field1_bigint;

\echo ##########################
\echo ##### Test12b
\echo ##########################
explain analyze select * from test_join_random_small_analyzed A
inner join test_join_random_big_analyzed B
on A.field1_bigint = B.field1_bigint;

\echo ##########################
\echo ##### Test14
\echo ##########################
explain analyze select * from test_DK_1_2 T1
inner join test_DK_2_1 T2
     on T1.field1_bigint = T2.field1_bigint
     and T1.field2_bigint = T2.field2_bigint;

\echo ##########################
\echo ##### Test15
\echo ##########################
explain analyze select * from test_DK_1_2 T1
inner join test_DK_1_2_bis T2
     on T1.field1_bigint = T2.field1_bigint
     and T1.field2_bigint = T2.field2_bigint;


\echo ##########################
\echo ##### Test16
\echo ##########################
explain analyze select * from test_DK_1_2 A
inner join test_join_bigint_analyzed B
on A.field1_bigint = B.field1_bigint;
